import React from 'react';
import Produtores from './Produtores';

export default function Home() {
    return <Produtores melhoresProdutores={false} />
}

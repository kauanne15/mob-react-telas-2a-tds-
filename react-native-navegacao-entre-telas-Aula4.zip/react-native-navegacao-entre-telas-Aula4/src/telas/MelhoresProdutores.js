import React from 'react';
import Produtores from './Produtores';

export default function MelhoresProdutores() {
    return <Produtores melhoresProdutores />
}
